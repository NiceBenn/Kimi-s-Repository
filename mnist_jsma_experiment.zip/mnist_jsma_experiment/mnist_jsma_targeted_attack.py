"""
MNIST数据集上的JSMA定向攻击实现
Jacobian-based Saliency Map Attack (JSMA) Targeted Attack on MNIST

作者: [胡杰]
日期: 2025-12-27
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
import os

# 直接导入torchattacks（需要先安装：pip install -e . 或 pip install torchattacks）
try:
    import torchattacks
except ImportError:
    raise ImportError(
        "torchattacks未安装！请先安装：\n"
        "1. 如果在本项目目录：pip install -e .\n"
        "2. 或从PyPI安装：pip install torchattacks\n"
        "3. 或从GitHub安装：pip install git+https://github.com/Harry24k/adversarial-attacks-pytorch.git"
    )


class SimpleMNISTModel(nn.Module):
    """
    简单的MNIST分类模型
    用于演示JSMA攻击
    """
    def __init__(self):
        super(SimpleMNISTModel, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)
        self.dropout = nn.Dropout(0.5)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 64 * 7 * 7)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        return x


def load_mnist_data(n_examples=10, batch_size=1):
    """
    加载MNIST数据集
    
    Args:
        n_examples: 要加载的样本数量
        batch_size: 批次大小
    
    Returns:
        images: 图像张量
        labels: 标签张量
    """
    transform = transforms.Compose([
        transforms.ToTensor(),  # 将图像转换为张量，并归一化到[0,1]
    ])
    
    # 加载MNIST测试集（数据保存在当前目录的data文件夹）
    data_root = os.path.join(os.path.dirname(__file__), 'data')
    testset = torchvision.datasets.MNIST(
        root=data_root, 
        train=False, 
        download=True, 
        transform=transform
    )
    
    # 创建数据加载器
    testloader = torch.utils.data.DataLoader(
        testset, 
        batch_size=batch_size, 
        shuffle=False
    )
    
    # 获取前n_examples个样本
    images_list = []
    labels_list = []
    for i, (images, labels) in enumerate(testloader):
        images_list.append(images)
        labels_list.append(labels)
        if (i + 1) * batch_size >= n_examples:
            break
    
    images = torch.cat(images_list, dim=0)[:n_examples]
    labels = torch.cat(labels_list, dim=0)[:n_examples]
    
    return images, labels


def train_simple_model(model, device, epochs=3):
    """
    训练一个简单的MNIST模型（如果模型未训练）
    
    Args:
        model: 模型实例
        device: 设备（cpu或cuda）
        epochs: 训练轮数
    """
    print("开始训练模型...")
    
    transform = transforms.Compose([
        transforms.ToTensor(),
    ])
    
    # 数据保存在当前目录的data文件夹
    data_root = os.path.join(os.path.dirname(__file__), 'data')
    trainset = torchvision.datasets.MNIST(
        root=data_root, 
        train=True, 
        download=True, 
        transform=transform
    )
    
    trainloader = torch.utils.data.DataLoader(
        trainset, 
        batch_size=64, 
        shuffle=True
    )
    
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    model.train()
    for epoch in range(epochs):
        running_loss = 0.0
        for i, (images, labels) in enumerate(trainloader):
            images, labels = images.to(device), labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
            if (i + 1) % 200 == 0:
                print(f'Epoch [{epoch+1}/{epochs}], Step [{i+1}/{len(trainloader)}], Loss: {running_loss/200:.4f}')
                running_loss = 0.0
    
    model.eval()
    print("模型训练完成！")


def evaluate_model(model, images, labels, device):
    """
    评估模型准确率
    
    Args:
        model: 模型
        images: 图像张量
        labels: 标签张量
        device: 设备
    
    Returns:
        accuracy: 准确率
        predictions: 预测结果
    """
    model.eval()
    with torch.no_grad():
        images = images.to(device)
        outputs = model(images)
        _, predictions = torch.max(outputs, 1)
        correct = (predictions.cpu() == labels).sum().item()
        accuracy = correct / len(labels) * 100.0
    return accuracy, predictions.cpu()


def jsma_targeted_attack(model, images, labels, target_labels, device, theta=1.0, gamma=0.1):
    """
    使用JSMA进行定向攻击
    
    Args:
        model: 要攻击的模型
        images: 原始图像
        labels: 原始标签
        target_labels: 目标标签（希望模型误分类成的类别）
        device: 设备
        theta: 扰动长度（默认1.0，即像素值增加1.0）
        gamma: 最多修改的像素百分比（默认0.1，即10%）
    
    Returns:
        adv_images: 对抗样本
        success_rate: 攻击成功率
    """
    print(f"\n开始JSMA定向攻击...")
    print(f"参数设置: theta={theta}, gamma={gamma}")
    print(f"目标: 将图像误分类为目标类别")
    
    # 创建JSMA攻击对象
    atk = torchattacks.JSMA(model, theta=theta, gamma=gamma)
    
    # 设置为定向攻击模式
    atk.set_mode_targeted_by_label()
    
    print(f"\n原始标签: {labels.tolist()}")
    print(f"目标标签: {target_labels.tolist()}")
    
    # 执行攻击
    adv_images = atk(images.to(device), target_labels.to(device))
    
    # 评估攻击效果
    _, adv_predictions = evaluate_model(model, adv_images, labels, device)
    
    # 计算成功率（预测为目标标签的比例）
    success = (adv_predictions == target_labels).sum().item()
    success_rate = success / len(labels) * 100.0
    
    print(f"\n攻击结果:")
    print(f"预测标签: {adv_predictions.tolist()}")
    print(f"攻击成功率: {success_rate:.2f}%")
    
    return adv_images.cpu(), success_rate


def calculate_perturbation_stats(original_images, adv_images):
    """
    计算扰动统计信息
    
    Args:
        original_images: 原始图像
        adv_images: 对抗样本
    
    Returns:
        stats: 统计信息字典
    """
    # 计算L0距离（修改的像素数量）
    diff = torch.abs(adv_images - original_images)
    l0_distances = (diff > 1e-6).sum(dim=(1, 2, 3)).float()
    
    # 计算L2距离
    l2_distances = torch.norm(
        (adv_images - original_images).view(len(original_images), -1), 
        p=2, 
        dim=1
    )
    
    # 计算Linf距离
    linf_distances = torch.max(
        torch.abs(adv_images - original_images).view(len(original_images), -1), 
        dim=1
    )[0]
    
    stats = {
        'l0_mean': l0_distances.mean().item(),
        'l0_std': l0_distances.std().item(),
        'l2_mean': l2_distances.mean().item(),
        'l2_std': l2_distances.std().item(),
        'linf_mean': linf_distances.mean().item(),
        'linf_std': linf_distances.std().item(),
    }
    
    return stats


def visualize_results(original_images, adv_images, original_labels, target_labels, 
                      adv_predictions, save_path='./jsma_results.png'):
    """
    可视化攻击结果
    
    Args:
        original_images: 原始图像
        adv_images: 对抗样本
        original_labels: 原始标签
        target_labels: 目标标签
        adv_predictions: 对抗样本的预测结果
        save_path: 保存路径
    """
    n_samples = min(len(original_images), 10)  # 最多显示10个样本
    
    fig, axes = plt.subplots(3, n_samples, figsize=(2*n_samples, 6))
    if n_samples == 1:
        axes = axes.reshape(-1, 1)
    
    for i in range(n_samples):
        # 原始图像
        axes[0, i].imshow(original_images[i].squeeze().numpy(), cmap='gray')
        axes[0, i].set_title(f'原始\n标签: {original_labels[i].item()}', fontsize=10)
        axes[0, i].axis('off')
        
        # 对抗样本
        axes[1, i].imshow(adv_images[i].squeeze().numpy(), cmap='gray')
        axes[1, i].set_title(f'对抗样本\n目标: {target_labels[i].item()}\n预测: {adv_predictions[i].item()}', 
                            fontsize=10, color='green' if adv_predictions[i] == target_labels[i] else 'red')
        axes[1, i].axis('off')
        
        # 扰动（放大显示）
        perturbation = torch.abs(adv_images[i] - original_images[i]).squeeze()
        axes[2, i].imshow(perturbation.numpy(), cmap='hot')
        axes[2, i].set_title(f'扰动\n修改像素数: {(perturbation > 1e-6).sum().item()}', fontsize=10)
        axes[2, i].axis('off')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"\n结果已保存到: {save_path}")
    plt.show()


def main():
    """
    主函数：执行完整的JSMA定向攻击流程
    """
    print("=" * 60)
    print("MNIST数据集上的JSMA定向攻击实验")
    print("=" * 60)
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\n使用设备: {device}")
    
    # 设置随机种子以保证可复现性
    torch.manual_seed(42)
    np.random.seed(42)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(42)
    
    # 1. 加载数据
    print("\n[步骤1] 加载MNIST测试数据...")
    n_examples = 10  # 测试样本数量
    images, labels = load_mnist_data(n_examples=n_examples, batch_size=1)
    print(f"已加载 {len(images)} 个样本")
    
    # 2. 加载或训练模型
    print("\n[步骤2] 准备模型...")
    model = SimpleMNISTModel().to(device)
    
    # 尝试加载预训练模型，如果不存在则训练
    model_path = os.path.join(os.path.dirname(__file__), 'mnist_model.pth')
    if os.path.exists(model_path):
        print(f"加载预训练模型: {model_path}")
        model.load_state_dict(torch.load(model_path, map_location=device))
        model.eval()
    else:
        print("未找到预训练模型，开始训练...")
        train_simple_model(model, device, epochs=3)
        print(f"保存模型到: {model_path}")
        torch.save(model.state_dict(), model_path)
    
    # 3. 评估原始模型准确率
    print("\n[步骤3] 评估原始模型准确率...")
    original_accuracy, original_predictions = evaluate_model(model, images, labels, device)
    print(f"原始准确率: {original_accuracy:.2f}%")
    
    # 只对正确分类的样本进行攻击
    correct_mask = (original_predictions == labels)
    if correct_mask.sum() == 0:
        print("警告: 没有正确分类的样本，无法进行攻击！")
        return
    
    images_to_attack = images[correct_mask]
    labels_to_attack = labels[correct_mask]
    original_predictions_to_attack = original_predictions[correct_mask]
    
    print(f"正确分类的样本数: {len(images_to_attack)}")
    
    # 4. 设置目标标签（定向攻击）
    print("\n[步骤4] 设置目标标签...")
    # 方法1: 将标签循环右移1位（0->1, 1->2, ..., 9->0）
    target_labels = (labels_to_attack + 1) % 10
    
    # 方法2: 可以手动指定目标标签
    # target_labels = torch.tensor([5, 5, 5, 5, 5, 5, 5, 5, 5, 5])[:len(labels_to_attack)]
    
    print(f"原始标签: {labels_to_attack.tolist()}")
    print(f"目标标签: {target_labels.tolist()}")
    
    # 5. 执行JSMA定向攻击
    print("\n[步骤5] 执行JSMA定向攻击...")
    adv_images, success_rate = jsma_targeted_attack(
        model=model,
        images=images_to_attack,
        labels=labels_to_attack,
        target_labels=target_labels,
        device=device,
        theta=1.0,  # 扰动长度（像素值修改幅度，MNIST像素值范围[0,1]）
        gamma=0.1   # 最多修改10%的像素
    )
    
    # 6. 计算扰动统计
    print("\n[步骤6] 计算扰动统计信息...")
    stats = calculate_perturbation_stats(images_to_attack, adv_images)
    print(f"\n扰动统计:")
    print(f"  L0距离 (修改像素数): {stats['l0_mean']:.2f} ± {stats['l0_std']:.2f}")
    print(f"  L2距离: {stats['l2_mean']:.4f} ± {stats['l2_std']:.4f}")
    print(f"  Linf距离: {stats['linf_mean']:.4f} ± {stats['linf_std']:.4f}")
    
    # 7. 可视化结果
    print("\n[步骤7] 可视化攻击结果...")
    _, adv_predictions = evaluate_model(model, adv_images, labels_to_attack, device)
    visualize_results(
        images_to_attack, 
        adv_images, 
        labels_to_attack, 
        target_labels, 
        adv_predictions,
        save_path=os.path.join(os.path.dirname(__file__), 'mnist_jsma_targeted_results.png')
    )
    
    # 8. 总结
    print("\n" + "=" * 60)
    print("实验总结")
    print("=" * 60)
    print(f"测试样本数: {len(images_to_attack)}")
    print(f"原始准确率: {original_accuracy:.2f}%")
    print(f"攻击成功率: {success_rate:.2f}%")
    print(f"平均修改像素数: {stats['l0_mean']:.2f}")
    print("=" * 60)


if __name__ == '__main__':
    main()

