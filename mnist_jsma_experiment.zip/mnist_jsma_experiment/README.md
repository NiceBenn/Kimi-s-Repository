# MNIST JSMA 定向攻击实验

## 📁 文件夹说明

本文件夹包含完整的MNIST数据集JSMA定向攻击实验代码和文档。

## 🚀 快速开始

```bash
# 1. 安装torchattacks包（在任何位置都可以）
pip install torchattacks
# 或从GitHub安装: pip install git+https://github.com/Harry24k/adversarial-attacks-pytorch.git

# 2. 安装其他依赖
pip install torch torchvision numpy matplotlib scipy tqdm

# 3. 进入实验文件夹（可以移动到任何位置）
cd mnist_jsma_experiment

# 4. 测试环境（可选）
python test_mnist_jsma.py

# 5. 运行实验
python mnist_jsma_targeted_attack.py
```

## 📄 文件说明

### 核心文件
- **mnist_jsma_targeted_attack.py** - 主程序文件（必须）
- **test_mnist_jsma.py** - 环境测试脚本
- **mnist_jsma_requirements.txt** - 依赖包列表

### 文档文件
- **README.md** - 本文件，文件夹说明
- **MNIST_JSMA_README.md** - 详细使用说明文档（推荐阅读）
- **QUICKSTART.md** - 5分钟快速开始指南
- **运行指南.md** - 详细运行步骤和问题解答
- **代码详细说明.md** - 代码原理和函数详解
- **安装说明.md** - torchattacks安装指南
- **实验文件说明.md** - 文件清单和项目结构
- **文件清单.md** - 完整文件清单

### 输出文件（运行后生成）
- **mnist_jsma_targeted_results.png** - 攻击结果可视化图像
- **mnist_model.pth** - 训练好的模型
- **data/** - MNIST数据集文件夹

## 📖 详细文档

请查看 `MNIST_JSMA_README.md` 获取完整的使用说明。

## ⚠️ 注意事项

1. **必须先安装torchattacks包**：
   - `pip install torchattacks`（推荐）
   - 或 `pip install git+https://github.com/Harry24k/adversarial-attacks-pytorch.git`
   - 或 `pip install -e .`（如果在项目根目录）
2. **实验文件夹可以移动到任何位置**，不依赖项目根目录
3. 首次运行需要下载MNIST数据集（自动下载到当前目录的`data`文件夹）
4. 所有输出文件保存在本文件夹中

