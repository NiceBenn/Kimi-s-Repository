# 快速开始指南

## 5分钟快速上手

### 步骤1: 安装依赖

```bash
# 安装PyTorch（根据你的系统选择）
# CPU版本
pip install torch torchvision

# 或使用CUDA版本（推荐，速度更快）
pip install torch torchvision --index-url https://pytorch.org/get-started/locally/

# 安装torchattacks库（三种方式任选其一）
# 方式1: 从PyPI安装（最简单）
pip install torchattacks

# 方式2: 从GitHub安装最新版本
pip install git+https://github.com/Harry24k/adversarial-attacks-pytorch.git

# 方式3: 本地安装（如果下载了源代码）
cd adversarial-attacks-pytorch
pip install -e .

# 安装其他依赖
pip install numpy matplotlib scipy tqdm
```

### 步骤2: 进入实验文件夹

```bash
# 注意：实验文件夹可以移动到任何位置，不依赖项目根目录
cd mnist_jsma_experiment
```

### 步骤3: 测试环境

```bash
python test_mnist_jsma.py
```

如果看到"✓ 所有测试通过"，说明环境配置正确！

### 步骤4: 运行实验

```bash
python mnist_jsma_targeted_attack.py
```

### 步骤5: 查看结果

程序会自动：
- 下载MNIST数据集（如果首次运行，保存在当前目录的`data`文件夹）
- 训练或加载模型
- 执行JSMA定向攻击
- 生成结果图像：`mnist_jsma_targeted_results.png`（在当前文件夹）

## 预期运行时间

- **首次运行**: 约5-10分钟（需要下载数据和训练模型）
- **后续运行**: 约1-3分钟（使用已训练的模型）

## 输出文件

所有文件都保存在实验文件夹中：
- `mnist_jsma_targeted_results.png`: 攻击结果可视化
- `mnist_model.pth`: 训练好的模型（首次运行后生成）
- `data/`: MNIST数据集（自动下载）

## 遇到问题？

查看详细文档：`MNIST_JSMA_README.md`

