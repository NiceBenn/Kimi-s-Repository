"""
快速测试脚本：验证MNIST JSMA攻击代码的基本功能
"""

import sys
import os

def test_imports():
    """测试所有必要的导入"""
    print("测试导入...")
    try:
        import torch
        print(f"✓ PyTorch {torch.__version__}")
    except ImportError as e:
        print(f"✗ PyTorch导入失败: {e}")
        return False
    
    try:
        import torchvision
        print(f"✓ torchvision {torchvision.__version__}")
    except ImportError as e:
        print(f"✗ torchvision导入失败: {e}")
        return False
    
    try:
        import numpy as np
        print(f"✓ numpy {np.__version__}")
    except ImportError as e:
        print(f"✗ numpy导入失败: {e}")
        return False
    
    try:
        import matplotlib
        print(f"✓ matplotlib {matplotlib.__version__}")
    except ImportError as e:
        print(f"✗ matplotlib导入失败: {e}")
        return False
    
    try:
        import torchattacks
        print(f"✓ torchattacks {torchattacks.__version__}")
    except ImportError as e:
        print(f"✗ torchattacks导入失败: {e}")
        print("  提示: 请先安装torchattacks:")
        print("    方法1: pip install -e . (在项目根目录)")
        print("    方法2: pip install torchattacks")
        print("    方法3: pip install git+https://github.com/Harry24k/adversarial-attacks-pytorch.git")
        return False
    
    return True

def test_jsma_import():
    """测试JSMA攻击类是否可以导入"""
    print("\n测试JSMA攻击类...")
    try:
        from torchattacks import JSMA
        print("✓ JSMA类导入成功")
        return True
    except Exception as e:
        print(f"✗ JSMA类导入失败: {e}")
        return False

def test_main_module():
    """测试主模块是否可以导入"""
    print("\n测试主模块...")
    try:
        # 添加当前目录到路径以便导入主模块
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if current_dir not in sys.path:
            sys.path.insert(0, current_dir)
        
        import mnist_jsma_targeted_attack
        print("✓ 主模块导入成功")
        
        # 检查主要函数是否存在
        assert hasattr(mnist_jsma_targeted_attack, 'load_mnist_data')
        assert hasattr(mnist_jsma_targeted_attack, 'jsma_targeted_attack')
        assert hasattr(mnist_jsma_targeted_attack, 'main')
        print("✓ 主要函数检查通过")
        return True
    except Exception as e:
        print(f"✗ 主模块导入失败: {e}")
        return False

def test_device():
    """测试设备可用性"""
    print("\n测试设备...")
    try:
        import torch
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"✓ 可用设备: {device}")
        if torch.cuda.is_available():
            print(f"  CUDA设备: {torch.cuda.get_device_name(0)}")
        return True
    except Exception as e:
        print(f"✗ 设备测试失败: {e}")
        return False

def main():
    """运行所有测试"""
    print("=" * 60)
    print("MNIST JSMA攻击代码测试")
    print("=" * 60)
    
    results = []
    results.append(("导入测试", test_imports()))
    results.append(("JSMA类测试", test_jsma_import()))
    results.append(("主模块测试", test_main_module()))
    results.append(("设备测试", test_device()))
    
    print("\n" + "=" * 60)
    print("测试结果总结")
    print("=" * 60)
    
    all_passed = True
    for test_name, result in results:
        status = "✓ 通过" if result else "✗ 失败"
        print(f"{test_name}: {status}")
        if not result:
            all_passed = False
    
    print("=" * 60)
    
    if all_passed:
        print("\n✓ 所有测试通过！代码应该可以正常运行。")
        print("\n下一步: 运行 python mnist_jsma_targeted_attack.py")
    else:
        print("\n✗ 部分测试失败，请检查错误信息并修复。")
        print("\n常见问题:")
        print("1. 如果torchattacks导入失败，请运行: pip install -e .")
        print("2. 如果PyTorch导入失败，请安装: pip install torch torchvision")
    
    return all_passed

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)

