# MNIST数据集上的JSMA定向攻击实验

## 实验题目

在MNIST数据集上实现基于Jacobian-based Saliency Map Attack (JSMA)的定向攻击

## 项目简介

本项目实现了在MNIST手写数字数据集上使用JSMA（Jacobian-based Saliency Map Attack）方法进行定向对抗攻击。JSMA是一种基于雅可比矩阵显著性图的攻击方法，通过计算每个像素对模型输出的影响，选择最重要的像素进行修改，从而生成对抗样本。

### JSMA攻击原理

1. **雅可比矩阵计算**: 计算模型输出对输入图像每个像素的梯度（雅可比矩阵）
2. **显著性图构建**: 基于雅可比矩阵构建显著性图，找出哪些像素组合最能：
   - 增加目标类别的输出概率
   - 减少其他类别的输出概率
3. **迭代修改**: 每次选择显著性最高的2个像素进行修改
4. **终止条件**: 当模型预测为目标类别或达到最大迭代次数时停止

### 定向攻击说明

- **定向攻击（Targeted Attack）**: 目标是让模型将原始图像误分类为指定的目标类别
- 例如：原始图像是数字"3"，目标是将它误分类为"7"

## 环境配置

### 系统要求

- Python >= 3.6
- PyTorch >= 1.4.0
- CUDA（可选，用于GPU加速）

### 依赖安装

#### 方法1: 安装torchattacks包（推荐）

```bash
# 1. 安装PyTorch（根据你的CUDA版本选择）
# CPU版本
pip install torch torchvision

# CUDA 11.8版本
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# CUDA 12.1版本
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121

# 2. 安装torchattacks库（三种方式任选其一）

# 方式A: 从PyPI安装（推荐，最简单）
pip install torchattacks

# 方式B: 从GitHub安装最新版本
pip install git+https://github.com/Harry24k/adversarial-attacks-pytorch.git

# 方式C: 本地安装（如果下载了源代码）
cd adversarial-attacks-pytorch  # 进入项目根目录
pip install -e .

# 3. 安装其他依赖
pip install numpy matplotlib scipy tqdm
```

#### 方法2: 使用requirements.txt

```bash
# 先安装torchattacks（见方法1）
# 然后安装其他依赖
pip install -r mnist_jsma_requirements.txt
```

#### 方法3: 使用国内镜像源加速安装

```bash
# 使用清华镜像源
pip install torch torchvision -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install numpy matplotlib scipy tqdm -i https://pypi.tuna.tsinghua.edu.cn/simple

# 其他可选镜像源：
# 阿里云: https://mirrors.aliyun.com/pypi/simple/
# 豆瓣: https://pypi.douban.com/simple/
# 中科大: https://pypi.mirrors.ustc.edu.cn/simple/
```

### 验证安装

#### 方法1: 使用测试脚本（推荐）

```bash
python test_mnist_jsma.py
```

测试脚本会自动检查：
- 所有必要的包是否正确安装
- JSMA攻击类是否可以导入
- 主模块是否可以正常导入
- 设备（CPU/GPU）是否可用

#### 方法2: 手动验证

运行以下Python代码验证环境是否正确配置：

```python
import torch
import torchvision
import numpy as np
import matplotlib.pyplot as plt
import torchattacks

print(f"PyTorch版本: {torch.__version__}")
print(f"CUDA可用: {torch.cuda.is_available()}")
print(f"torchattacks版本: {torchattacks.__version__}")
```

## 使用方法

### 1. 快速开始

```bash
# 步骤1: 安装torchattacks（如果还没安装）
pip install torchattacks
# 或从GitHub安装: pip install git+https://github.com/Harry24k/adversarial-attacks-pytorch.git

# 步骤2: 进入实验文件夹（可以移动到任何位置）
cd mnist_jsma_experiment

# 步骤3: 测试环境（可选但推荐）
python test_mnist_jsma.py

# 步骤4: 运行主程序
python mnist_jsma_targeted_attack.py
```

### 2. 基本使用

进入实验文件夹后运行主程序：

```bash
cd mnist_jsma_experiment
python mnist_jsma_targeted_attack.py
```

### 2. 程序执行流程

程序会自动执行以下步骤：

1. **加载MNIST数据**: 从torchvision自动下载MNIST测试集（保存在当前目录的`data`文件夹）
2. **准备模型**: 
   - 如果存在预训练模型(`mnist_model.pth`)，则加载
   - 否则训练一个新的简单CNN模型（约3个epoch）
3. **评估原始准确率**: 测试模型在原始数据上的准确率
4. **执行JSMA攻击**: 对正确分类的样本进行定向攻击
5. **计算扰动统计**: 分析对抗样本与原始样本的差异
6. **可视化结果**: 生成对比图像并保存

### 3. 参数配置

可以在代码中修改以下参数：

```python
# 在main()函数中修改
n_examples = 10        # 测试样本数量
theta = 1.0            # 扰动长度（像素值修改幅度）
gamma = 0.1            # 最多修改的像素百分比（10%）

# 目标标签设置方式
target_labels = (labels_to_attack + 1) % 10  # 循环右移
# 或手动指定
# target_labels = torch.tensor([5, 5, 5, ...])  # 全部改为5
```

### 4. 输出结果

程序运行后会生成：

- **控制台输出**: 
  - 模型准确率
  - 攻击成功率
  - 扰动统计信息（L0、L2、Linf距离）
  
- **图像文件**: `mnist_jsma_experiment/mnist_jsma_targeted_results.png`
  - 第一行：原始图像及标签
  - 第二行：对抗样本及预测结果
  - 第三行：扰动可视化（红色表示修改的像素）

- **模型文件**: `mnist_jsma_experiment/mnist_model.pth`（如果训练了新模型）

**注意**: 所有输出文件都会保存在 `mnist_jsma_experiment` 文件夹中

## 代码结构说明

### 主要函数

1. **`load_mnist_data(n_examples, batch_size)`**
   - 功能：加载MNIST测试数据
   - 参数：样本数量、批次大小
   - 返回：图像张量和标签张量

2. **`train_simple_model(model, device, epochs)`**
   - 功能：训练简单的CNN模型用于MNIST分类
   - 参数：模型、设备、训练轮数

3. **`evaluate_model(model, images, labels, device)`**
   - 功能：评估模型准确率
   - 返回：准确率和预测结果

4. **`jsma_targeted_attack(...)`**
   - 功能：执行JSMA定向攻击
   - 参数：模型、图像、标签、目标标签、设备、攻击参数
   - 返回：对抗样本和成功率

5. **`calculate_perturbation_stats(original_images, adv_images)`**
   - 功能：计算扰动统计信息
   - 返回：L0、L2、Linf距离的均值和标准差

6. **`visualize_results(...)`**
   - 功能：可视化攻击结果
   - 生成对比图像并保存

### 模型架构

使用的简单CNN模型结构：

```
Conv2d(1, 32, kernel_size=3) -> ReLU -> MaxPool2d
Conv2d(32, 64, kernel_size=3) -> ReLU -> MaxPool2d
Linear(64*7*7, 128) -> ReLU -> Dropout(0.5)
Linear(128, 10)
```

## 实验结果示例

### 典型输出

```
============================================================
MNIST数据集上的JSMA定向攻击实验
============================================================

使用设备: cuda

[步骤1] 加载MNIST测试数据...
已加载 10 个样本

[步骤2] 准备模型...
加载预训练模型: ./mnist_model.pth

[步骤3] 评估原始模型准确率...
原始准确率: 100.00%

[步骤4] 设置目标标签...
原始标签: [7, 2, 1, 0, 4, 1, 4, 9, 5, 9]
目标标签: [8, 3, 2, 1, 5, 2, 5, 0, 6, 0]

[步骤5] 执行JSMA定向攻击...
开始JSMA定向攻击...
参数设置: theta=1.0, gamma=0.1
目标: 将图像误分类为目标类别

原始标签: [7, 2, 1, 0, 4, 1, 4, 9, 5, 9]
目标标签: [8, 3, 2, 1, 5, 2, 5, 0, 6, 0]

攻击结果:
预测标签: [8, 3, 2, 1, 5, 2, 5, 0, 6, 0]
攻击成功率: 100.00%

[步骤6] 计算扰动统计信息...
扰动统计:
  L0距离 (修改像素数): 45.20 ± 12.34
  L2距离: 0.1234 ± 0.0456
  Linf距离: 0.0234 ± 0.0123

[步骤7] 可视化攻击结果...
结果已保存到: ./mnist_jsma_targeted_results.png

============================================================
实验总结
============================================================
测试样本数: 10
原始准确率: 100.00%
攻击成功率: 100.00%
平均修改像素数: 45.20
============================================================
```

## 常见问题

### Q1: 程序运行很慢怎么办？

**A**: JSMA攻击需要计算雅可比矩阵，计算量较大。建议：
- 使用GPU加速（CUDA）
- 减少测试样本数量（`n_examples`）
- 减少最大修改像素比例（`gamma`）

### Q2: 攻击成功率很低怎么办？

**A**: 可以尝试：
- 增加`gamma`值（允许修改更多像素）
- 调整`theta`值（修改像素的幅度）
- 检查模型是否训练充分

### Q3: 如何修改目标标签？

**A**: 在`main()`函数中修改目标标签设置：
```python
# 方法1: 循环右移
target_labels = (labels_to_attack + 1) % 10

# 方法2: 全部改为指定数字
target_labels = torch.full_like(labels_to_attack, 5)

# 方法3: 手动指定每个样本的目标
target_labels = torch.tensor([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
```

### Q4: 如何保存和加载预训练模型？

**A**: 
- 保存：`torch.save(model.state_dict(), 'mnist_model.pth')`
- 加载：`model.load_state_dict(torch.load('mnist_model.pth'))`

### Q5: 内存不足怎么办？

**A**: 
- 减少批次大小（`batch_size=1`）
- 减少测试样本数量
- 使用CPU而不是GPU

## 参考文献

1. Papernot, N., et al. (2016). "The Limitations of Deep Learning in Adversarial Settings." IEEE Security and Privacy Workshops.

2. Torchattacks库: https://github.com/Harry24k/adversarial-attacks-pytorch

## 许可证

本项目基于MIT许可证。

## 联系方式

如有问题或建议，请联系：[你的邮箱]

---

**注意**: 本代码仅用于学术研究和教育目的。请勿用于恶意用途。

